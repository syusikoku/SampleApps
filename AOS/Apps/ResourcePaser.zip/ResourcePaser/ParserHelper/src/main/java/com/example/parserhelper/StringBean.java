package com.example.parserhelper;

public class StringBean {
    public String mName="";
    public String mEnContent="";
    public String mCaContent="";
    public String mEsContent="";
    public String mEuContent="";
    public String mGlContent="";
    public String mPtContent="";
    public String mZhRCNContent="";
    public String mZhRHKContent="";
    public String mTargetPath="";
}