class AppConsts {
  // http://www.liulongbin.top:3005/api/v2/movie/in_theaters
  // 电影列表相关
  static final String MOVIE_BASEURL =
      "http://www.liulongbin.top:3005/api/v2/movie/";
}
